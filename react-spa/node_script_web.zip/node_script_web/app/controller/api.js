'use strict';

const Controller = require('egg').Controller;
const fse = require('fs-extra')
const execa = require('execa')

class ApiController extends Controller {
  constructor(ctx) {
    super(ctx)
    // extend
    this.err = function (message, status = 403) {
      ctx.body = {
        message,
      }
      ctx.status = status
    }
    this.succ = function (result, status = 200) {
      ctx.body = {
        result,
      }
      ctx.status = status
    }
  }

  async post_query_file() {
    const { ctx, err, succ } = this
    const { condition, file_name, title } = ctx.request.body
    ctx.set('Access-Control-Allow-Origin', '*')
    ctx.set('Access-Control-Allow-Credentials', "true")
    ctx.set('Access-Control-Allow-Methods', '*')
    if (!condition || !file_name) {
      err('missing args')
      return
    }
    const path = `./script/${file_name}`
    // service
    const is_file_exists = await fse.pathExists(path)
    if (is_file_exists) {
      await fse.remove(path)
    }
    const template = `>${title || 'test'}
    ${condition}
    `
    await fse.outputFile(path, template)
    const data = await fse.readFile(path, 'utf8')

    succ(data)

  }

  async get_finanl_results() {
    const { ctx, err, succ } = this
    const { script, file_name } = ctx.query
    ctx.set('Access-Control-Allow-Origin', '*')
    ctx.set('Access-Control-Allow-Credentials', "true")
    ctx.set('Access-Control-Allow-Methods', '*')
    if (!script || !file_name) {
      err('missing args')
      return
    }
    const path = `./script/${file_name}`
    // service
    const is_file_exists = await fse.pathExists(path)
    if (is_file_exists) {
      await fse.remove(path)
    }
    await execa.shell(`cd ./script && sh ./${script}`)
    const data = await fse.readFile(path, 'utf8')
    const result_arr = data.split('\n')
    if (result_arr.length < 2) {
      succ([])
      return
    }
    const key_arr = result_arr[0].split('\t')
    const value_arr = result_arr[1].split('\t')

    const result = {}

    key_arr.map((t, i) => {
      result[t] = value_arr[i]
    })

    succ(result)
  }
}

module.exports = ApiController;