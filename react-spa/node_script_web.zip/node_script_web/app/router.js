'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  const ver = `/api/v1`
  router.get('/', controller.home.index);

  router.post(`${ver}/query-file`, controller.api.post_query_file);
  router.get(`${ver}/finanl-results`, controller.api.get_finanl_results);
};
