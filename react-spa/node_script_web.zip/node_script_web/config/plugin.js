'use strict';

// had enabled by egg
// exports.static = true;

// 模板渲染
exports.nunjucks = {
  enable: true,
  package: 'egg-view-nunjucks'
};
