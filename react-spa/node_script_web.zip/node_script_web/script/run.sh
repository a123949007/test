blastn -query test_input -db HN-16S/HN-16S -outfmt 6 -out test_output
cat test_output | sort -k1,1 -k12,12gr -k11,11g -k3,3gr | sort -u -k1,1 > best_hit.txt
cat header.txt best_hit.txt > final_results.txt
